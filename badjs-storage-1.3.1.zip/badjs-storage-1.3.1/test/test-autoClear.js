/**
 * Created by chriscai on 2015/1/14.
 */

var MongoClient = require('mongodb').MongoClient;

global.MONGDO_URL = "mongodb://localhost:27017/badjs";



 require('./autoClear');





