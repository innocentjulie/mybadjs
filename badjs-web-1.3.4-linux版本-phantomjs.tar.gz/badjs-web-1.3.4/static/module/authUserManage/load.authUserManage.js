var usermanger = require("./mod.authUserManage.js");

usermanger.init();