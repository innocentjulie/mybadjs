var projectTotal = require('./mod.projectTotal.js');

projectTotal.init();