var statistics = require("./mod.statistics");
statistics.init();

var last_select = require("../common/last.select");
last_select.init();