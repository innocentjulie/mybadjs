var usermanger = require("./mod.userManage");

usermanger.init();