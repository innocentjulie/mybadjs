var charts = require('./mod.charts');

charts.init();