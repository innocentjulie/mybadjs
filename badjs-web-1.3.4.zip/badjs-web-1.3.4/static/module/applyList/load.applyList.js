var applyList = require("./mod.applyList");

applyList.init();