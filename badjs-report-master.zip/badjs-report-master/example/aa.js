define( ["bb.js?bbb"],function (e){
    aaaa
});
