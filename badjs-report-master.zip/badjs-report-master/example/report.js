
define(function (require, exports, module){

    module.exports ={
        init : function (){
            bbbb+++1
        }
    }
});

s13cc();
